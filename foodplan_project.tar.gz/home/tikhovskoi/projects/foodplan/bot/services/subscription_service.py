from bot.adapters.subscription_repository import DjangoSubscriptionRepository
from payments.models import SubscriptionPlan

class SubscriptionService:
    def __init__(self, repository: DjangoSubscriptionRepository):
        self._repository = repository

    async def get_plan(self, plan_id: int) -> SubscriptionPlan:
        """ Получить план подписки по ID """
        return await SubscriptionPlan.objects.get(id=plan_id)

    async def check_active(self, telegram_id: int) -> bool:
        """ Проверить, активна ли подписка у пользователя """
        return await self._repository.is_active(telegram_id)

    async def extend_subscription(self, telegram_id: int, days: int) -> None:
        """ Продлить подписку на количество дней """
        await self._repository.extend(telegram_id, days)
