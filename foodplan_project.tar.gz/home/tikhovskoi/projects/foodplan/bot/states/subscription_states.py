from aiogram.fsm.state import State
from aiogram.fsm.states import StatesGroup

class SubscriptionStates(StatesGroup):
    waiting_for_subscription_choice = State() 
    waiting_for_plan_choice = State()  
