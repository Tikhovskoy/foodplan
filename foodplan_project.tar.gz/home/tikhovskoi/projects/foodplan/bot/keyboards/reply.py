from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# Клавиатура для выбора подтверждения подписки (Да/Нет)
def get_subscription_confirmation_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Да", callback_data="subscribe_yes")],
            [InlineKeyboardButton(text="❌ Нет", callback_data="subscribe_no")]
        ]
    )

# Клавиатура для кнопки покупки подписки (Купить/Отказаться)
def get_buy_subscription_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Купить подписку", callback_data="buy_subscription")],
            [InlineKeyboardButton(text="❌ Отказаться", callback_data="decline_subscription")]
        ]
    )

# Клавиатура для выбора типа питания
def get_meal_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🍳 Завтрак", callback_data="meal_breakfast")],
            [InlineKeyboardButton(text="🍝 Обед", callback_data="meal_lunch")],
            [InlineKeyboardButton(text="🍽 Ужин", callback_data="meal_dinner")]
        ]
    )

# Клавиатура для выбора диеты
def get_diet_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🥦 Веган", callback_data="diet_vegan")],
            [InlineKeyboardButton(text="🌾 Без глютена", callback_data="diet_glutenfree")],
            [InlineKeyboardButton(text="🍖 Без ограничений", callback_data="diet_none")]
        ]
    )

# Клавиатура для рецепта (главные действия)
def get_recipe_main_kb(recipe_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📋 Показать шаги", callback_data=f"show_steps_{recipe_id}")],
            [InlineKeyboardButton(text="🛒 Ингредиенты", callback_data=f"ingredients_{recipe_id}")],
            [
                InlineKeyboardButton(text="👍 Лайк", callback_data=f"like_{recipe_id}"),
                InlineKeyboardButton(text="👎 Дизлайк", callback_data=f"dislike_{recipe_id}")
            ],
            [InlineKeyboardButton(text="➡️ Следующий рецепт", callback_data="next_recipe")]
        ]
    )

# Клавиатура для навигации по шагам рецепта
def get_step_navigation_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="➡️ Следующий шаг", callback_data="next_step")]
        ]
    )

# Клавиатура для начала работы с ботом
def get_start_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Начать", callback_data="start")]
        ]
    )

# Клавиатура для возврата к рецепту
def get_back_to_recipe_kb(recipe_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Вернуться к рецепту", callback_data=f"back_to_recipe_{recipe_id}")]
        ]
    )

# Клавиатура для выбора тарифов подписки (с использованием кнопок для каждого тарифа)
def get_subscription_kb(buttons) -> InlineKeyboardMarkup:
    """
    Генерирует инлайн клавиатуру с кнопками для выбора тарифов.
    `buttons` - это список кортежей (название кнопки, id тарифа).
    """
    keyboard = InlineKeyboardMarkup(row_width=1) 
    for button in buttons:
        name, plan_id = button  # Получаем название тарифа и его ID
        keyboard.add(InlineKeyboardButton(name, callback_data=str(plan_id)))  # Добавляем кнопку с планом
    return keyboard
